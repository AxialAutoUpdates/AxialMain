ace.define("ace/snippets/php_laravel_blade",["require","exports","module"], function(require, exports, module) {
    "use strict";

    exports.snippetText =undefined;
    exports.scope = "php";

});                (function() {
                    ace.require(["ace/snippets/php_laravel_blade"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            